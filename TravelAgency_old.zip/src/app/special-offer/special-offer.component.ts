import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { BuyNowComponent } from '../buy-now/buy-now.component';
import { EditPackageComponent } from '../packages/edit-package/edit-package.component';
import { Package } from '../packages/package.model';
import { PackageService } from '../packages/package.service';

@Component({
  selector: 'app-special-offer',
  templateUrl: './special-offer.component.html',
  styleUrls: ['./special-offer.component.css'],
})
export class SpecialOfferComponent implements OnInit {
  constructor(
    private modalService: NgbModal,
    private packageService: PackageService
  ) {}

  specialPackage: Package;
  subscription: Subscription;

  ngOnInit(): void {
    this.packageService.fetchSpecialPackage().subscribe();
    this.subscription = this.packageService.specialPackageChanged.subscribe(
      (pack: Package) => {
        this.specialPackage = pack;
      }
    );
    // this.specialPackage = this.packageService.getSpecialPackage();
  }

  openBuyNowModal() {
    this.modalService.open(BuyNowComponent);
  }

  onEditPackage() {
    this.packageService.isSpecialOffer = true;
    this.modalService.open(EditPackageComponent);
  }
}
