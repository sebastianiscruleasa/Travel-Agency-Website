import { Component, Input, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BuyNowComponent } from 'src/app/buy-now/buy-now.component';
import { EditPackageComponent } from '../edit-package/edit-package.component';

import { Package } from '../package.model';
import { PackageService } from '../package.service';
@Component({
  selector: 'app-package-item',
  templateUrl: './package-item.component.html',
  styleUrls: ['./package-item.component.css'],
})
export class PackageItemComponent implements OnInit {
  @Input() pack: Package;
  @Input() index: number;
  constructor(
    private packageService: PackageService,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {}

  openBuyNowModal() {
    this.modalService.open(BuyNowComponent);
  }

  onDeletePackage() {
    this.packageService.deletePackage(this.index);
  }

  onEditPackage() {
    this.packageService.index = this.index;
    this.modalService.open(EditPackageComponent);
  }
}
